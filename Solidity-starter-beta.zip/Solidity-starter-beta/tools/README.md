# Solidity tools for Replit

This folder contains the UI for testing your contracts. You don't need to edit files in this folder.
